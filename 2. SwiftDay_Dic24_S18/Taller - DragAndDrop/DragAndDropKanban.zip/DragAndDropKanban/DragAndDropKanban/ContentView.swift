//
//  ContentView.swift
//  DragAndDropKanban
//
//  Created by Sergio Gonzalez on 02/12/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
        
                KanbanView()
                .tabItem {
                    Label("Strings", systemImage: "abc")
                }
            
                KanbanViewTask()
                .tabItem {
                    Label("Tasks", systemImage: "checkmark.seal.fill")
                }
        }
    }
}

#Preview {
    ContentView()
}

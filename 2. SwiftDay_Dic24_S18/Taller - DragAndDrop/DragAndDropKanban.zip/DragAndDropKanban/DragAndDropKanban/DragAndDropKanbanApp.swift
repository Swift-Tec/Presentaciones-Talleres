//
//  DragAndDropKanbanApp.swift
//  DragAndDropKanban
//
//  Created by Sergio Gonzalez on 02/12/24.
//

import SwiftUI

@main
struct DragAndDropKanbanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
